#include <Arduino.h>
#include <Servo.h>
#include <NeoPixelBus.h>

/*Pin definition*/
#define servoPin_L 9
#define servoPin_R 10
#define servoPin_T 11

#define SAOPin_GPIO1 5
#define SAOPin_GPIO2 6
#define SAOPin_I2C_SDA A4
#define SAOPin_I2C_CLK A5
/****************/
/*Wave*/
uint8_t waveLeft_count;
uint8_t waveLeft_pos;
uint8_t waveLeft_target;
uint8_t waveLeft_eye_cover_count;
#define waveLeft_max 140
#define waveLeft_min 100
#define waveLeft_resting 0
#define waveLeft_eye_cover 180
uint8_t waveRight_count;
uint8_t waveRight_pos;
uint8_t waveRight_target;
uint8_t waveRight_eye_cover_count;
#define waveRight_max 40
#define waveRight_min 80
#define waveRight_resting 180
#define waveRight_eye_cover 0
unsigned long wavetimer;
#define waveintervalms 5
/*    */
/*Head*/
#define head_max 118
#define head_center 88
#define head_min 58
uint8_t head_count;
uint8_t head_pos = head_center;
uint8_t head_target = head_center;
unsigned long headtimer;
#define headintervalms 5
/******/
/*Eyes*/
#define rightEye 0
#define leftEye 1
uint8_t colorSaturation = 255;
uint8_t Eye_color_index;
RgbwColor rightEye_color(0,0,0,0);
RgbwColor leftEye_color(0,0,0,0);
uint16_t rightEye_hue;
uint16_t leftEye_hue;
RgbwColor red(255, 0, 0, 0);
RgbwColor green(0, 255, 0, 0);
RgbwColor blue(0, 0, 255, 0);
RgbwColor white(0, 0, 0, 255);
RgbwColor black(0 ,0 ,0 ,0);
unsigned long eyetimer;
#define eyeintervalms 16
const uint16_t PixelCount = 2; // this example assumes 4 pixels, making it smaller will cause a failure
const uint8_t PixelPin = SAOPin_GPIO1;  // make sure to set this to the correct pin, ignored for Esp8266
#define brightness_max 80
#define brightness_min 30
uint8_t brightness;
NeoPixelBus<NeoGrbwFeature, NeoSk6812Method> strip(PixelCount, PixelPin);
/******/

#define action_interval_min 2000
#define action_interval_max 10000
unsigned long action_interval = 5000;
unsigned long last_action;

Servo servo_L;
Servo servo_R;
Servo servo_T;

//const float PI = 3.14159265358979323846;
//const float TWO_PI = 2 * PI;

float mySin(float x) {
    // Ensure x is in the range [-pi, pi]
    x = fmod(x + PI, TWO_PI) - PI;

    // Initialize variables for the Taylor series expansion
    float result = x;
    float term = x;
    float x_squared = x * x;
    float sign = -1.0;

    // Compute additional terms of the Taylor series
    for (int i = 1; i <= 9; ++i) { // Adjust the number of terms as needed for accuracy
        term *= x_squared / ((2 * i) * (2 * i + 1));
        result += sign * term;
        sign *= -1.0;
    }

    return result;
}

float mapFloat(float x, float in_min, float in_max, float out_min, float out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


RgbwColor HsvToRgbw(float h, uint8_t s, uint8_t v) {
  float vh = fmod(h, 360.0); // Make sure hue is in the range 0-359
  float vs = fmin(fmax((float)s / 255.0, 0.0), 1.0); // Clamp saturation to 0-1
  float vv = fmin(fmax((float)v / 255.0, 0.0), 1.0); // Map value from 0-255 to 0-1

  float c = vv * vs;
  float x = c * (1 - fabs(fmod(vh / 60.0, 2) - 1));
  float m = vv - c;

  float rf, gf, bf, wf;

  if (vh >= 0 && vh < 60) {
    rf = c;
    gf = x;
    bf = 0;
  } else if (vh >= 60 && vh < 120) {
    rf = x;
    gf = c;
    bf = 0;
  } else if (vh >= 120 && vh < 180) {
    rf = 0;
    gf = c;
    bf = x;
  } else if (vh >= 180 && vh < 240) {
    rf = 0;
    gf = x;
    bf = c;
  } else if (vh >= 240 && vh < 300) {
    rf = x;
    gf = 0;
    bf = c;
  } else { // vh >= 300 && vh < 360
    rf = c;
    gf = 0;
    bf = x;
  }

  // Calculate the maximum of the red, green, and blue components
  float maxRGB = fmax(rf, fmax(gf, bf));

  // Adjust the white component based on the maximum RGB component
  wf = m + (maxRGB - m) * (1 - vs);

  uint8_t r = round((rf + m) * 255);
  uint8_t g = round((gf + m) * 255);
  uint8_t b = round((bf + m) * 255);
  uint8_t w = round((wf) * 255);

  return RgbwColor(r, g, b, w);
}

void Eye_color_randomizer(uint8_t eye){
  Eye_color_index = random(0,5);
  uint16_t hue;
  switch (Eye_color_index)
  {
  case 0:
    hue = 0; //red
    break;
  case 1:
    hue = 120; //green
    break;
  case 2:
    hue = 240; //blue
    break;
  case 3:
    hue = 300; //pink
    break;
  case 4:
    hue = 60; //yellow
    break;
  case 5:
    //rainbow
    break;
  default:
    break;
  }
  if(eye >= 128){
    leftEye_hue = hue;
  }
  else{
    rightEye_hue = hue;
  }
}

void eyefunc(){
  static unsigned long blinktimer;
  static unsigned long blinklenght;
  static bool blink;
  if(blinktimer + random(5000,20000) < millis() && !blink){
    blinktimer = millis();
    blinklenght = random(250,400);
    blink = true;
    if(random(0,255) > 50){
      Eye_color_randomizer(random(0,255));
    }
    
  }
  if(blinktimer+blinklenght > millis() && blink){
    strip.SetPixelColor(leftEye, black);
    strip.SetPixelColor(rightEye, black);
  }
  else{
    if(Eye_color_index == 5 ){
      float rainbow = mapFloat(mySin(millis() / 1000.0 * 0.05 * PI), -1.0, 1.0, 0.0, 359.0);
      brightness = 80;
      leftEye_color = HsvToRgbw(rainbow, colorSaturation, brightness);
      rightEye_color = HsvToRgbw(rainbow, colorSaturation, brightness);
    }
    else{
      brightness = mapFloat(mySin((millis() / 1000.0) * 1 * PI), -1.0, 1.0, brightness_min, brightness_max); // Sine wave brightness between 0 and 255
      leftEye_color = HsvToRgbw(leftEye_hue, colorSaturation, brightness);
      rightEye_color = HsvToRgbw(rightEye_hue, colorSaturation, brightness);
    }
    strip.SetPixelColor(leftEye, leftEye_color);
    strip.SetPixelColor(rightEye, rightEye_color);
  }
  if(blinktimer+blinklenght > millis() && blink){
    blink = false;
  }
  eyetimer = millis();
  strip.Show();
}

void wavefunc(){
  if(waveLeft_count == 0 && waveLeft_eye_cover_count == 0){
    waveLeft_target = waveLeft_resting;
  }
  if(waveRight_count == 0 && waveRight_eye_cover_count == 0){
    waveRight_target = waveRight_resting;
  }
  if(waveLeft_pos == waveLeft_target && waveLeft_eye_cover_count > 0){
    if(waveLeft_eye_cover_count >= 1){
      waveLeft_eye_cover_count--;
      if(waveLeft_target == waveLeft_eye_cover){
        waveLeft_target = waveLeft_max;
        Eye_color_randomizer(leftEye);
      }
      else{
        waveLeft_target = waveLeft_eye_cover;
      }
      
    }
  }
  if(waveRight_pos == waveRight_target && waveRight_eye_cover_count > 0){
    if(waveRight_eye_cover_count >= 1){
      waveRight_eye_cover_count--;
      if(waveRight_target == waveRight_eye_cover){
        waveRight_target = waveRight_max;
        Eye_color_randomizer(rightEye);
      }
      else{
        waveRight_target = waveRight_eye_cover;
      }
      
    }
  }
  if(waveLeft_pos != waveLeft_target){
    if(waveLeft_pos < waveLeft_target){
      waveLeft_pos++;
    }
    else{
      waveLeft_pos--;
    }
  }
  if(waveLeft_pos == waveLeft_target && waveLeft_count > 0){
    if(waveLeft_count >= 1){
      waveLeft_count--;
      if(waveLeft_target == waveLeft_min){
        waveLeft_target = waveLeft_max;
      }
      else{
        waveLeft_target = waveLeft_min;
      }
      
    }
  }
  if(waveRight_pos != waveRight_target){
    if(waveRight_pos < waveRight_target){
      waveRight_pos++;
    }
    else{
      waveRight_pos--;
    }
  }
  if(waveRight_pos == waveRight_target && waveRight_count > 0){
    if(waveRight_count >= 1){
      waveRight_count--;
      if(waveRight_target == waveRight_min){
        waveRight_target = waveRight_max;
      }
      else{
        waveRight_target = waveRight_min;
      }
    }
  }
  wavetimer = millis();
}

void headfunc(){
  if(head_pos != head_target){
    if(head_pos < head_target){
      head_pos++;
    }
    else{
      head_pos--;
    }
  }
  if(head_pos == head_target){
    if(head_count >= 2){
      head_count--;
      uint8_t head_next = random(0,2);
      if(head_next == 0){
        head_target = head_max;
      }
      else if(head_next == 1){
        head_target = head_center;
      }
      else if(head_next == 2){
        head_target = head_min;
      }

    }
    else if(head_count == 1){
      head_count--;
    }
  }
  headtimer = millis();
}

void diceroll(){
  head_count = random(0,255);
  if(head_count < 128){
    head_count = random(1,3);
  }
  else{
    head_count = 0;
  }
  if(!head_count){
    uint8_t which_arm = random(0,3);
    if(which_arm == 0){
      waveLeft_count = random(4,20);
    }
    else if(which_arm == 1){
      waveRight_count = random(4,20);
    }
    else if(which_arm == 2){
      waveLeft_count = random(4,20);
      waveRight_count = waveLeft_count;
    }
    else{
      waveLeft_eye_cover_count = random(2,4);
      waveRight_eye_cover_count = waveLeft_eye_cover_count;
    }
  }
  action_interval = random(action_interval_min,action_interval_max);
  last_action = millis();
}

void setup() {
  Serial.begin(9600);
  strip.Begin();
  strip.SetPixelColor(rightEye, black);
  strip.SetPixelColor(leftEye, black);
  strip.Show(); // clears all digits by default
  servo_L.attach(servoPin_L);
  servo_R.attach(servoPin_R);
  servo_T.attach(servoPin_T);
  wavetimer = millis();
  headtimer = wavetimer;
  eyetimer = wavetimer;
  servo_T.write(head_center);
  delay(250);
  servo_L.write(waveLeft_resting);
  delay(250);
  servo_R.write(waveRight_resting);
  delay(500);
  strip.SetPixelColor(rightEye, green);
  strip.Show();
  delay(250);
  strip.SetPixelColor(leftEye, green);
  strip.Show();
  delay(2000);
}

void loop() {
  if(!head_count && !waveLeft_count && !waveRight_count && millis() > (last_action+action_interval)){
    diceroll();
  }
  if(wavetimer+waveintervalms < millis()){
    wavefunc();
  }
  if(headtimer+headintervalms < millis()){
    headfunc();
  }
  if(eyetimer+eyeintervalms < millis()){
    eyefunc();
  }
  servo_L.write(waveLeft_pos);
  servo_R.write(waveRight_pos);
  servo_T.write(head_pos);
}